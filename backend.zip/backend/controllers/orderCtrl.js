import orderModel from "../models/OrderModel.js";
import userModel from "../models/userModel.js";
import Razorpay from "razorpay";

if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
    throw new Error("Razorpay API keys are missing");
}

const razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET
});

const placeOrder = async (req, res) => {
    const frontend_url = process.env.FRONTEND_URL || "http://localhost:5175";

    try {
        // Creating a new order in DB
        const newOrder = new orderModel({
            userId: req.body.userId,
            items: req.body.items,
            amount: req.body.amount,
            address: req.body.address
        });

        await newOrder.save();
        await userModel.findByIdAndUpdate(req.body.userId, { $set: { cartData: {} } });

        // Calculating total amount in paise (Razorpay uses paise)
        const totalAmount = (req.body.amount + 20) * 100; // Adding delivery charges (₹20)

        // Creating an order in Razorpay
        const razorpayOrder = await razorpay.orders.create({
            amount: totalAmount,
            currency: "INR",
            receipt: `order_${newOrder._id}`,
            payment_capture: 1 // Auto capture payment
        });

        res.json({ success: true, order_id: razorpayOrder.id });
    } catch (error) {
        console.error("Order placement error:", error);
        res.status(500).json({ success: false, message: "Internal Server Error" });
    }
};

export { placeOrder };


