import mongoose from "mongoose";

export const connectDB = async () => {
    await mongoose.connect('mongodb+srv://dakshbhavsar85:XZBdL4f1EHelIPyE@cluster0.bi1fl.mongodb.net/food-del').then(()=>console.log("DB Connected"));
}